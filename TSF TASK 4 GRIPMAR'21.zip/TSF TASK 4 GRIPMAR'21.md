# <center>TSF TASK 4 - GRIP MARCH'21</center>
# <center>ADITYA AMBWANI<center>

# <center>Exploratory Data Analysis - Terrorism<center>

### Objective:-
- Perform ‘Exploratory Data Analysis’ on dataset ‘Global Terrorism'
- As a security/defense analyst, try to find out the hot zone of terrorism.
- What all security issues and insights you can derive by EDA?


```python
# Importing libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')
!pip install wordcloud
```

    Requirement already satisfied: wordcloud in c:\users\adi\anaconda3\lib\site-packages (1.8.1)
    Requirement already satisfied: pillow in c:\users\adi\anaconda3\lib\site-packages (from wordcloud) (8.0.1)
    Requirement already satisfied: matplotlib in c:\users\adi\anaconda3\lib\site-packages (from wordcloud) (3.3.2)
    Requirement already satisfied: numpy>=1.6.1 in c:\users\adi\anaconda3\lib\site-packages (from wordcloud) (1.19.2)
    Requirement already satisfied: kiwisolver>=1.0.1 in c:\users\adi\anaconda3\lib\site-packages (from matplotlib->wordcloud) (1.3.0)
    Requirement already satisfied: pyparsing!=2.0.4,!=2.1.2,!=2.1.6,>=2.0.3 in c:\users\adi\anaconda3\lib\site-packages (from matplotlib->wordcloud) (2.4.7)
    Requirement already satisfied: cycler>=0.10 in c:\users\adi\anaconda3\lib\site-packages (from matplotlib->wordcloud) (0.10.0)
    Requirement already satisfied: python-dateutil>=2.1 in c:\users\adi\anaconda3\lib\site-packages (from matplotlib->wordcloud) (2.8.1)
    Requirement already satisfied: certifi>=2020.06.20 in c:\users\adi\anaconda3\lib\site-packages (from matplotlib->wordcloud) (2020.6.20)
    Requirement already satisfied: six in c:\users\adi\anaconda3\lib\site-packages (from cycler>=0.10->matplotlib->wordcloud) (1.15.0)
    


```python
# Reading our dataset
data=pd.read_csv('globalterrorismdb_0718dist.csv',encoding='Latin1')
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>eventid</th>
      <th>iyear</th>
      <th>imonth</th>
      <th>iday</th>
      <th>approxdate</th>
      <th>extended</th>
      <th>resolution</th>
      <th>country</th>
      <th>country_txt</th>
      <th>region</th>
      <th>...</th>
      <th>addnotes</th>
      <th>scite1</th>
      <th>scite2</th>
      <th>scite3</th>
      <th>dbsource</th>
      <th>INT_LOG</th>
      <th>INT_IDEO</th>
      <th>INT_MISC</th>
      <th>INT_ANY</th>
      <th>related</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>197000000001</td>
      <td>1970</td>
      <td>7</td>
      <td>2</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>58</td>
      <td>Dominican Republic</td>
      <td>2</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PGIS</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>197000000002</td>
      <td>1970</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>130</td>
      <td>Mexico</td>
      <td>1</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PGIS</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>197001000001</td>
      <td>1970</td>
      <td>1</td>
      <td>0</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>160</td>
      <td>Philippines</td>
      <td>5</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PGIS</td>
      <td>-9</td>
      <td>-9</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>197001000002</td>
      <td>1970</td>
      <td>1</td>
      <td>0</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>78</td>
      <td>Greece</td>
      <td>8</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PGIS</td>
      <td>-9</td>
      <td>-9</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>197001000003</td>
      <td>1970</td>
      <td>1</td>
      <td>0</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>101</td>
      <td>Japan</td>
      <td>4</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PGIS</td>
      <td>-9</td>
      <td>-9</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>181686</th>
      <td>201712310022</td>
      <td>2017</td>
      <td>12</td>
      <td>31</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>182</td>
      <td>Somalia</td>
      <td>11</td>
      <td>...</td>
      <td>NaN</td>
      <td>"Somalia: Al-Shabaab Militants Attack Army Che...</td>
      <td>"Highlights: Somalia Daily Media Highlights 2 ...</td>
      <td>"Highlights: Somalia Daily Media Highlights 1 ...</td>
      <td>START Primary Collection</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>181687</th>
      <td>201712310029</td>
      <td>2017</td>
      <td>12</td>
      <td>31</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>200</td>
      <td>Syria</td>
      <td>10</td>
      <td>...</td>
      <td>NaN</td>
      <td>"Putin's 'victory' in Syria has turned into a ...</td>
      <td>"Two Russian soldiers killed at Hmeymim base i...</td>
      <td>"Two Russian servicemen killed in Syria mortar...</td>
      <td>START Primary Collection</td>
      <td>-9</td>
      <td>-9</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>181688</th>
      <td>201712310030</td>
      <td>2017</td>
      <td>12</td>
      <td>31</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>160</td>
      <td>Philippines</td>
      <td>5</td>
      <td>...</td>
      <td>NaN</td>
      <td>"Maguindanao clashes trap tribe members," Phil...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>START Primary Collection</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>181689</th>
      <td>201712310031</td>
      <td>2017</td>
      <td>12</td>
      <td>31</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>92</td>
      <td>India</td>
      <td>6</td>
      <td>...</td>
      <td>NaN</td>
      <td>"Trader escapes grenade attack in Imphal," Bus...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>START Primary Collection</td>
      <td>-9</td>
      <td>-9</td>
      <td>0</td>
      <td>-9</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>181690</th>
      <td>201712310032</td>
      <td>2017</td>
      <td>12</td>
      <td>31</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>160</td>
      <td>Philippines</td>
      <td>5</td>
      <td>...</td>
      <td>NaN</td>
      <td>"Security tightened in Cotabato following IED ...</td>
      <td>"Security tightened in Cotabato City," Manila ...</td>
      <td>NaN</td>
      <td>START Primary Collection</td>
      <td>-9</td>
      <td>-9</td>
      <td>0</td>
      <td>-9</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>181691 rows × 135 columns</p>
</div>




```python
# Calculating coloumns and rows 
data.shape
```




    (181691, 135)




```python
# Seeing all the headings of coloumn
data.columns.values
```




    array(['eventid', 'iyear', 'imonth', 'iday', 'approxdate', 'extended',
           'resolution', 'country', 'country_txt', 'region', 'region_txt',
           'provstate', 'city', 'latitude', 'longitude', 'specificity',
           'vicinity', 'location', 'summary', 'crit1', 'crit2', 'crit3',
           'doubtterr', 'alternative', 'alternative_txt', 'multiple',
           'success', 'suicide', 'attacktype1', 'attacktype1_txt',
           'attacktype2', 'attacktype2_txt', 'attacktype3', 'attacktype3_txt',
           'targtype1', 'targtype1_txt', 'targsubtype1', 'targsubtype1_txt',
           'corp1', 'target1', 'natlty1', 'natlty1_txt', 'targtype2',
           'targtype2_txt', 'targsubtype2', 'targsubtype2_txt', 'corp2',
           'target2', 'natlty2', 'natlty2_txt', 'targtype3', 'targtype3_txt',
           'targsubtype3', 'targsubtype3_txt', 'corp3', 'target3', 'natlty3',
           'natlty3_txt', 'gname', 'gsubname', 'gname2', 'gsubname2',
           'gname3', 'gsubname3', 'motive', 'guncertain1', 'guncertain2',
           'guncertain3', 'individual', 'nperps', 'nperpcap', 'claimed',
           'claimmode', 'claimmode_txt', 'claim2', 'claimmode2',
           'claimmode2_txt', 'claim3', 'claimmode3', 'claimmode3_txt',
           'compclaim', 'weaptype1', 'weaptype1_txt', 'weapsubtype1',
           'weapsubtype1_txt', 'weaptype2', 'weaptype2_txt', 'weapsubtype2',
           'weapsubtype2_txt', 'weaptype3', 'weaptype3_txt', 'weapsubtype3',
           'weapsubtype3_txt', 'weaptype4', 'weaptype4_txt', 'weapsubtype4',
           'weapsubtype4_txt', 'weapdetail', 'nkill', 'nkillus', 'nkillter',
           'nwound', 'nwoundus', 'nwoundte', 'property', 'propextent',
           'propextent_txt', 'propvalue', 'propcomment', 'ishostkid',
           'nhostkid', 'nhostkidus', 'nhours', 'ndays', 'divert',
           'kidhijcountry', 'ransom', 'ransomamt', 'ransomamtus',
           'ransompaid', 'ransompaidus', 'ransomnote', 'hostkidoutcome',
           'hostkidoutcome_txt', 'nreleased', 'addnotes', 'scite1', 'scite2',
           'scite3', 'dbsource', 'INT_LOG', 'INT_IDEO', 'INT_MISC', 'INT_ANY',
           'related'], dtype=object)




```python
# Checking for some more information on dataset
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 181691 entries, 0 to 181690
    Columns: 135 entries, eventid to related
    dtypes: float64(55), int64(22), object(58)
    memory usage: 187.1+ MB
    


```python
# Describing the dataset in a summarized way
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>eventid</th>
      <th>iyear</th>
      <th>imonth</th>
      <th>iday</th>
      <th>extended</th>
      <th>country</th>
      <th>region</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>specificity</th>
      <th>...</th>
      <th>ransomamt</th>
      <th>ransomamtus</th>
      <th>ransompaid</th>
      <th>ransompaidus</th>
      <th>hostkidoutcome</th>
      <th>nreleased</th>
      <th>INT_LOG</th>
      <th>INT_IDEO</th>
      <th>INT_MISC</th>
      <th>INT_ANY</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1.816910e+05</td>
      <td>181691.000000</td>
      <td>181691.000000</td>
      <td>181691.000000</td>
      <td>181691.000000</td>
      <td>181691.000000</td>
      <td>181691.000000</td>
      <td>177135.000000</td>
      <td>1.771340e+05</td>
      <td>181685.000000</td>
      <td>...</td>
      <td>1.350000e+03</td>
      <td>5.630000e+02</td>
      <td>7.740000e+02</td>
      <td>552.000000</td>
      <td>10991.000000</td>
      <td>10400.000000</td>
      <td>181691.000000</td>
      <td>181691.000000</td>
      <td>181691.000000</td>
      <td>181691.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2.002705e+11</td>
      <td>2002.638997</td>
      <td>6.467277</td>
      <td>15.505644</td>
      <td>0.045346</td>
      <td>131.968501</td>
      <td>7.160938</td>
      <td>23.498343</td>
      <td>-4.586957e+02</td>
      <td>1.451452</td>
      <td>...</td>
      <td>3.172530e+06</td>
      <td>5.784865e+05</td>
      <td>7.179437e+05</td>
      <td>240.378623</td>
      <td>4.629242</td>
      <td>-29.018269</td>
      <td>-4.543731</td>
      <td>-4.464398</td>
      <td>0.090010</td>
      <td>-3.945952</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.325957e+09</td>
      <td>13.259430</td>
      <td>3.388303</td>
      <td>8.814045</td>
      <td>0.208063</td>
      <td>112.414535</td>
      <td>2.933408</td>
      <td>18.569242</td>
      <td>2.047790e+05</td>
      <td>0.995430</td>
      <td>...</td>
      <td>3.021157e+07</td>
      <td>7.077924e+06</td>
      <td>1.014392e+07</td>
      <td>2940.967293</td>
      <td>2.035360</td>
      <td>65.720119</td>
      <td>4.543547</td>
      <td>4.637152</td>
      <td>0.568457</td>
      <td>4.691325</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.970000e+11</td>
      <td>1970.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>-53.154613</td>
      <td>-8.618590e+07</td>
      <td>1.000000</td>
      <td>...</td>
      <td>-9.900000e+01</td>
      <td>-9.900000e+01</td>
      <td>-9.900000e+01</td>
      <td>-99.000000</td>
      <td>1.000000</td>
      <td>-99.000000</td>
      <td>-9.000000</td>
      <td>-9.000000</td>
      <td>-9.000000</td>
      <td>-9.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.991021e+11</td>
      <td>1991.000000</td>
      <td>4.000000</td>
      <td>8.000000</td>
      <td>0.000000</td>
      <td>78.000000</td>
      <td>5.000000</td>
      <td>11.510046</td>
      <td>4.545640e+00</td>
      <td>1.000000</td>
      <td>...</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>-9.900000e+01</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>-99.000000</td>
      <td>-9.000000</td>
      <td>-9.000000</td>
      <td>0.000000</td>
      <td>-9.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2.009022e+11</td>
      <td>2009.000000</td>
      <td>6.000000</td>
      <td>15.000000</td>
      <td>0.000000</td>
      <td>98.000000</td>
      <td>6.000000</td>
      <td>31.467463</td>
      <td>4.324651e+01</td>
      <td>1.000000</td>
      <td>...</td>
      <td>1.500000e+04</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>4.000000</td>
      <td>0.000000</td>
      <td>-9.000000</td>
      <td>-9.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2.014081e+11</td>
      <td>2014.000000</td>
      <td>9.000000</td>
      <td>23.000000</td>
      <td>0.000000</td>
      <td>160.000000</td>
      <td>10.000000</td>
      <td>34.685087</td>
      <td>6.871033e+01</td>
      <td>1.000000</td>
      <td>...</td>
      <td>4.000000e+05</td>
      <td>0.000000e+00</td>
      <td>1.273412e+03</td>
      <td>0.000000</td>
      <td>7.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2.017123e+11</td>
      <td>2017.000000</td>
      <td>12.000000</td>
      <td>31.000000</td>
      <td>1.000000</td>
      <td>1004.000000</td>
      <td>12.000000</td>
      <td>74.633553</td>
      <td>1.793667e+02</td>
      <td>5.000000</td>
      <td>...</td>
      <td>1.000000e+09</td>
      <td>1.320000e+08</td>
      <td>2.750000e+08</td>
      <td>48000.000000</td>
      <td>7.000000</td>
      <td>2769.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 77 columns</p>
</div>




```python
# Checking for null values in our dataset
data.isnull().sum()
```




    eventid            0
    iyear              0
    imonth             0
    iday               0
    approxdate    172452
                   ...  
    INT_LOG            0
    INT_IDEO           0
    INT_MISC           0
    INT_ANY            0
    related       156653
    Length: 135, dtype: int64




```python
# Dropping all the null values
# data.dropna(axis=1,inplace=True)
# data.isnull().sum()
```


```python
# Seeing correlation between different variables
data.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>eventid</th>
      <th>iyear</th>
      <th>imonth</th>
      <th>iday</th>
      <th>extended</th>
      <th>country</th>
      <th>region</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>specificity</th>
      <th>...</th>
      <th>ransomamt</th>
      <th>ransomamtus</th>
      <th>ransompaid</th>
      <th>ransompaidus</th>
      <th>hostkidoutcome</th>
      <th>nreleased</th>
      <th>INT_LOG</th>
      <th>INT_IDEO</th>
      <th>INT_MISC</th>
      <th>INT_ANY</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>eventid</th>
      <td>1.000000</td>
      <td>0.999996</td>
      <td>0.002706</td>
      <td>0.018336</td>
      <td>0.091761</td>
      <td>-0.135039</td>
      <td>0.401371</td>
      <td>0.166886</td>
      <td>0.003907</td>
      <td>0.030641</td>
      <td>...</td>
      <td>-0.009990</td>
      <td>-0.018001</td>
      <td>-0.014094</td>
      <td>-0.165422</td>
      <td>0.256113</td>
      <td>-0.181612</td>
      <td>-0.143600</td>
      <td>-0.133252</td>
      <td>-0.077852</td>
      <td>-0.175605</td>
    </tr>
    <tr>
      <th>iyear</th>
      <td>0.999996</td>
      <td>1.000000</td>
      <td>0.000139</td>
      <td>0.018254</td>
      <td>0.091754</td>
      <td>-0.135023</td>
      <td>0.401384</td>
      <td>0.166933</td>
      <td>0.003917</td>
      <td>0.030626</td>
      <td>...</td>
      <td>-0.009984</td>
      <td>-0.018216</td>
      <td>-0.014238</td>
      <td>-0.165375</td>
      <td>0.256092</td>
      <td>-0.181556</td>
      <td>-0.143601</td>
      <td>-0.133253</td>
      <td>-0.077847</td>
      <td>-0.175596</td>
    </tr>
    <tr>
      <th>imonth</th>
      <td>0.002706</td>
      <td>0.000139</td>
      <td>1.000000</td>
      <td>0.005497</td>
      <td>-0.000468</td>
      <td>-0.006305</td>
      <td>-0.002999</td>
      <td>-0.015978</td>
      <td>-0.003880</td>
      <td>0.003621</td>
      <td>...</td>
      <td>-0.000710</td>
      <td>0.046989</td>
      <td>0.058878</td>
      <td>-0.016597</td>
      <td>0.011295</td>
      <td>-0.011535</td>
      <td>-0.002302</td>
      <td>-0.002034</td>
      <td>-0.002554</td>
      <td>-0.006336</td>
    </tr>
    <tr>
      <th>iday</th>
      <td>0.018336</td>
      <td>0.018254</td>
      <td>0.005497</td>
      <td>1.000000</td>
      <td>-0.004700</td>
      <td>0.003468</td>
      <td>0.009710</td>
      <td>0.003423</td>
      <td>-0.002285</td>
      <td>-0.006991</td>
      <td>...</td>
      <td>0.012755</td>
      <td>-0.010502</td>
      <td>0.003148</td>
      <td>-0.006581</td>
      <td>-0.006706</td>
      <td>0.001765</td>
      <td>-0.001540</td>
      <td>-0.001621</td>
      <td>-0.002027</td>
      <td>-0.001199</td>
    </tr>
    <tr>
      <th>extended</th>
      <td>0.091761</td>
      <td>0.091754</td>
      <td>-0.000468</td>
      <td>-0.004700</td>
      <td>1.000000</td>
      <td>-0.020466</td>
      <td>0.038389</td>
      <td>-0.024749</td>
      <td>0.000523</td>
      <td>0.057897</td>
      <td>...</td>
      <td>-0.008114</td>
      <td>0.028177</td>
      <td>0.001966</td>
      <td>0.009367</td>
      <td>0.233293</td>
      <td>-0.192155</td>
      <td>0.071768</td>
      <td>0.075147</td>
      <td>0.027335</td>
      <td>0.080767</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>nreleased</th>
      <td>-0.181612</td>
      <td>-0.181556</td>
      <td>-0.011535</td>
      <td>0.001765</td>
      <td>-0.192155</td>
      <td>-0.044331</td>
      <td>-0.149511</td>
      <td>0.002790</td>
      <td>-0.017745</td>
      <td>-0.030631</td>
      <td>...</td>
      <td>0.054571</td>
      <td>0.034843</td>
      <td>0.049322</td>
      <td>0.016832</td>
      <td>-0.555478</td>
      <td>1.000000</td>
      <td>0.039388</td>
      <td>0.040947</td>
      <td>0.085055</td>
      <td>0.064759</td>
    </tr>
    <tr>
      <th>INT_LOG</th>
      <td>-0.143600</td>
      <td>-0.143601</td>
      <td>-0.002302</td>
      <td>-0.001540</td>
      <td>0.071768</td>
      <td>0.069904</td>
      <td>-0.082584</td>
      <td>-0.099827</td>
      <td>0.002272</td>
      <td>0.073022</td>
      <td>...</td>
      <td>0.035821</td>
      <td>0.031079</td>
      <td>0.007029</td>
      <td>-0.045504</td>
      <td>-0.015442</td>
      <td>0.039388</td>
      <td>1.000000</td>
      <td>0.996211</td>
      <td>0.052537</td>
      <td>0.891051</td>
    </tr>
    <tr>
      <th>INT_IDEO</th>
      <td>-0.133252</td>
      <td>-0.133253</td>
      <td>-0.002034</td>
      <td>-0.001621</td>
      <td>0.075147</td>
      <td>0.067564</td>
      <td>-0.071917</td>
      <td>-0.094470</td>
      <td>0.002268</td>
      <td>0.071333</td>
      <td>...</td>
      <td>0.039053</td>
      <td>0.041983</td>
      <td>0.013162</td>
      <td>-0.039844</td>
      <td>-0.016234</td>
      <td>0.040947</td>
      <td>0.996211</td>
      <td>1.000000</td>
      <td>0.082014</td>
      <td>0.893811</td>
    </tr>
    <tr>
      <th>INT_MISC</th>
      <td>-0.077852</td>
      <td>-0.077847</td>
      <td>-0.002554</td>
      <td>-0.002027</td>
      <td>0.027335</td>
      <td>0.207281</td>
      <td>0.043139</td>
      <td>0.097652</td>
      <td>0.000371</td>
      <td>-0.019197</td>
      <td>...</td>
      <td>0.023815</td>
      <td>0.125162</td>
      <td>0.037227</td>
      <td>0.129274</td>
      <td>-0.119776</td>
      <td>0.085055</td>
      <td>0.052537</td>
      <td>0.082014</td>
      <td>1.000000</td>
      <td>0.252193</td>
    </tr>
    <tr>
      <th>INT_ANY</th>
      <td>-0.175605</td>
      <td>-0.175596</td>
      <td>-0.006336</td>
      <td>-0.001199</td>
      <td>0.080767</td>
      <td>0.153118</td>
      <td>-0.047900</td>
      <td>-0.041530</td>
      <td>0.002497</td>
      <td>0.061389</td>
      <td>...</td>
      <td>0.028054</td>
      <td>0.053484</td>
      <td>0.007275</td>
      <td>0.056438</td>
      <td>-0.061946</td>
      <td>0.064759</td>
      <td>0.891051</td>
      <td>0.893811</td>
      <td>0.252193</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
<p>77 rows × 77 columns</p>
</div>



## Visualising Dataset


```python
# Plotting terrorism year by year
plt.subplots(figsize=(20,10))
sns.countplot(x=data['iyear'])
plt.ylabel('Terrorist Activity in Numbers')
plt.xlabel('Year')
plt.title("Terrorism year by year")
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_13_0.png)
    


Conclusion:- Most number of terrorist attacks happened in 2014.


```python
# Plotting terrorism country by country
plt.subplots(figsize=(15,15))
sns.barplot(x=data['country_txt'].value_counts()[:20].index,y=data['country_txt'].value_counts()[:20].values)
plt.ylabel('Terrorist Activity in Numbers')
plt.xlabel('COuntries')
plt.title("Terrorism Country by Country")
plt.xticks(rotation=45)
plt.show()
```


    
![png](output_15_0.png)
    


Conclsuion:- Most terrorist activities happend in Iraq till now with more than 23000 attacks in numbers.


```python
# Plotting terrorism region by region
plt.subplots(figsize=(20,10))
sns.countplot(x=data['region_txt'])
plt.ylabel('Terrorist Activity in Numbers')
plt.xlabel('Region')
plt.title("Terrorism Region by Region")
plt.xticks(rotation=90)
plt.show()
```


    
![png](output_17_0.png)
    


Conclsuion:- Middle East and North Africa has highest number of terrorist activities with nearly 50000 in numbers.


```python
# Plotting terrorism by types of terrorist activities
plt.subplots(figsize=(15,15))
sns.barplot(x=data['attacktype1_txt'].value_counts()[:20].index,y=data['attacktype1_txt'].value_counts()[:20].values)
plt.ylabel('Terrorist Activity in Numbers')
plt.xlabel('Methods of Attacks')
plt.title("Terrorism by Attack Types")
plt.xticks(rotation=45)
plt.show()
```


    
![png](output_19_0.png)
    


Conclsuion:- Bombing/Explosion are the most common methods used for Terrorist Activities with nearly 90000 in numbers.


```python
# Successfull Attacks
sns.countplot(x='success', data=data, palette='hls')
```




    <AxesSubplot:xlabel='success', ylabel='count'>




    
![png](output_21_1.png)
    


Conclusion:- Around 160000 terrorist attacks are successfull and around 20000 are unsccessfull till now.


```python
# Plotting targets of attack
fig, ax = plt.subplots(figsize=(15,10))
ax = sns.countplot(x = 'targtype1_txt', data=data, palette='icefire', order=data['targtype1_txt'].value_counts().index)
_ = plt.xlabel('Targets of attack')
_ = plt.setp(ax.get_xticklabels(), rotation = 90)
```


    
![png](output_23_0.png)
    

Conclusion:- From the above figure we can see that private citizens and property is the highest target and the top five targets              are private citizens and property, military, police, government(general) where people can be found in high numbers              and also law & order is affected.

```python
# Plotting weapons of attacks
fig, ax = plt.subplots(figsize=(10, 5))
ax = sns.countplot(x='weaptype1_txt', data=data, palette='inferno', order=data['weaptype1_txt'].value_counts().index)
_ = plt.xlabel('Weapon Used')
_ = plt.setp(ax.get_xticklabels(), rotation = 90)
```


    
![png](output_25_0.png)
    


Conclusion:- Weapon that is mostly used in terrorist activities is Explosives.


```python
fig, ax = plt.subplots(figsize=(15,10))
ax = sns.countplot(x='gname', data=data, palette='inferno', order=data['gname'].value_counts()[1:16].index)
_ = plt.xlabel('Terrorist group name')
_ = plt.setp(ax.get_xticklabels(), rotation=90) 
```


    
![png](output_27_0.png)
    


Conclusion:- Taliban is the most active terrorist group as the most number of activities has been done by this group.


```python
# Summary of our dataset
print("Country with the most attacks:",data['country_txt'].value_counts().idxmax())
print("City with the most attacks:",data['city'].value_counts().index[1])
print("Region with the most attacks:",data['region_txt'].value_counts().idxmax())
print("Country with the most attacks:",data['country_txt'].value_counts().idxmax())
print("Year with the most attacks:",data['iyear'].value_counts().idxmax())
print("Month with the most attacks:",data['imonth'].value_counts().idxmax())
print("Country with the most attacks:",data['country_txt'].value_counts().idxmax())
print("Country with the most attacks:",data['gname'].value_counts().index[1])
print("Most attacks types:",data['attacktype1_txt'].value_counts().idxmax())
```

    Country with the most attacks: Iraq
    City with the most attacks: Baghdad
    Region with the most attacks: Middle East & North Africa
    Country with the most attacks: Iraq
    Year with the most attacks: 2014
    Month with the most attacks: 5
    Country with the most attacks: Iraq
    Country with the most attacks: Taliban
    Most attacks types: Bombing/Explosion
    


```python
from scipy import signal
from wordcloud import WordCloud
plt.subplots(figsize=(15,20))
wordcloud=WordCloud(background_color='Black').generate(''.join(data['provstate'].dropna(False)))
plt.axis('on')
plt.imshow(wordcloud)
plt.show()
```


    
![png](output_30_0.png)
    

